
// Pequenos aprimoramentos de UX
document.addEventListener('DOMContentLoaded', function(){
  const navToggle = document.getElementById('nav-toggle');
  const nav = document.getElementById('primary-nav');
  if (navToggle && nav) {
    nav.addEventListener('click', (e)=>{
      if (e.target.tagName === 'A') navToggle.checked = false;
    });
  }
});
