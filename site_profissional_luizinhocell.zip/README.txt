# LuizinhoCell — Site Profissional (estático)

Este pacote contém um site profissional, responsivo e leve, pronto para hospedar.

## Como publicar (cPanel/Hostinger/Locaweb/HostGator)
1) Acesse o **Gerenciador de Arquivos** e entre na pasta `public_html` (ou `www`).
2) Faça upload do arquivo `site_profissional_luizinhocell.zip` e **Extraia**.
3) Garanta que `index.html` está diretamente em `public_html`.
4) Acesse seu domínio e teste.

## Como configurar o formulário (Formspree)
- Crie uma conta no Formspree e obtenha um endpoint (ex.: `https://formspree.io/f/abcde`).
- Abra `contato.html` e substitua o atributo `action` do `<form>` pelo seu endpoint.
- Opcional: ative reCAPTCHA no Formspree.

## SEO
- Edite `domain` dentro das metatags (OG) se desejar.
- `robots.txt` e `sitemap.xml` já estão prontos.
- Estrutura `JSON-LD` em todas as páginas como `LocalBusiness`.

## Personalização
- Cores, tipografia e layout em `assets/css/styles.css`.
- Scripts em `assets/js/app.js`.
- Imagens em `assets/img/` (substitua os placeholders).

## Páginas
- `/` (home), `/servicos.html`, `/sobre.html`, `/contato.html`, `/blog.html`
- Legais: `/politica-privacidade.html`, `/termos.html`

## Dúvidas
Envie seu domínio e publico um checklist para apontar DNS/Cloudflare e SSL.
